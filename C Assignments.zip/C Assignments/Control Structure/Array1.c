/**
Title : Array: 1.Program to Print Transpose of a Matrix
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int row,col;
    printf("Enter how many rows you want\n");
    scanf("%d",&row);
    printf("Enter how many columns you want\n");
    scanf("%d",&col);
    int a[row][col],i,j;
    printf("Enter elements in matrix\n");
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Matrix before Transposition: \n");
     for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
    printf("Matrix After Transposition: \n");
     for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            printf("%d ",a[j][i]);
        }
        printf("\n");
    }
    return 0;
}
