/**
Title : Program to Print the Pattern
Date : 19/9/2017
*/
/*#include <stdio.h>

int main()
{
    int i,x,sum=0,j;
    for(i=0;i<5;i++)
    {
        // logic for space
        for(j=i;j<5;j++)
        {
            printf(" ");
        }
        // logic for print number triangle
        sum=sum+pow(10,i);
        printf("%d",sum*sum);
        printf("\n");
    }
    return 0;
}*/
