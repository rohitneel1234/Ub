/**
Title : Array: 4.Program to Find Smallest Among N Numbers
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int size,i,small;
    printf("Enter how many elements you want\n");
    scanf("%d",&size);
    int elements[size];
    printf("Enter elements :\n");
    for(i=0;i<size;i++)
    {
        scanf("%d",&elements[i]);
    }
    small=elements[0];
    for(i=1;i<size;i++)
    {
        if(small>elements[i])
        {
            small=elements[i];
        }
    }
    printf("Smallest number is %d\n",small);
    return 0;
}
