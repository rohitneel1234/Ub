/**
Title : Que 14. Example 2.5: A company insures its drivers in the following cases : (1) the driver is married.
(2)unmarried, male & above 30 years of age. (3)unmarried, female & above 25 years of age.

Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int age;
    char ch,gender;
    printf("Driver is Married then Enter M/m\n");
    printf("Driver is unmarried then enter U/u\n");
    scanf("%c",&ch);
    if(ch=='M' || ch=='m' || ch=='U' || ch =='u')
    {
        if(ch=='M' || ch=='m')
        {
            printf("Driver is married and This person is insure as a driver in company\n");
        }
        else
        {
            fflush(stdin);
            printf("Enter person is Male or female : m/f\n");
            scanf("%c",&gender);
            printf("Enter age of person : \n");
            scanf("%d",&age);
            if(gender=='m' && age>30)
            {
                printf("This person is insure as a driver in company");
            }
            else if (gender=='f' && age > 25)
            {
                printf("This person is insure as a driver in company");
            }
            else
            {
                printf("The person is not insure as a driver\n");
            }
        }
    }
    return 0;
}
