/**
Title :Loop : 1.
Date : 19/09/2017
*/
/*#include <stdio.h>

int main(void) {

   int i, x;

   printf("Input integer ");
   scanf("%d", &x);

   for (i=1; i<=x; i++){
       printf("%d times\n", i);
   }

   return (0);
}*/
/*
Output:
Input integer 5
1 times
2 times
3 times
4 times
5 times
*/
/**
Explanation :
1. Start
2. Take input from user : How much times loop will be executed
3. print how much times loop is executed.
4. Stop
*/
