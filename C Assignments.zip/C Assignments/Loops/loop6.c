/**
Title :6. Loop : Write a program to read in 10 numbers and compute the average, maximum and minimum values.
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number[10],i,sum=0,small,bigno; // declare integer array
    float avg;
    printf("Enter 10 numbers\n");
    for(i=0;i<10;i++)
    {
        scanf("%d",&number[i]); // add elements in array
    }
    // Average of 10 Numbers
    for(i=0;i<10;i++)
    {
        sum=sum+number[i];
    }
    avg=sum/10;// calculate avg of 10 numbers
    printf("Average of 10 numbers is %f\n",avg);
    // Find Minimum value
    small=number[0];
    for(i=1;i<10;i++)
    {
        if(small>number[i])
        {
            small=number[i];
        }
    }
    printf("Smallest number is %d\n",small);
    // find Maximum value
    bigno=number[0];
    for(i=1;i<10;i++)
    {
        if(bigno<number[i])
        {
            bigno=number[i];
        }
    }
     printf("Biggest number is %d\n",bigno);
    return 0;
}
/* Output :
Enter 10 numbers
45
4
8
74
25
14
6
9
20
75
Average of 10 numbers is 28.000000
Smallest number is 4
Biggest number is 75

*/
