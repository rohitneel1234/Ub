/**
Title :Loop : 5.
Date : 19/09/2017
*/
#include <stdio.h>

int main(void) {

   int i, j;

   for (i=0; i<10; i++){
       for (j=i; j>0; j--){
           printf(" ");
       }
       for (j=0; j<10-i; j++){
           printf(" *");
       }
       printf("\n");
   }

   return (0);
  }
/*
Output :
 * * * * * * * * * *
  * * * * * * * * *
   * * * * * * * *
    * * * * * * *
     * * * * * *
      * * * * *
       * * * *
        * * *
         * *
          *
*/
/**
Explanation :
1. Start
2. Outer loop gives number of rows
3. There are 2 loops in Outer loop :1. First loop give space.Spaces are increases according to outer loop condition
    2. second loop print * According to condition
4. Stop
*/

