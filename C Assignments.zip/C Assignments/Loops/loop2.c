/**
Title :Loop : 2.
Date : 19/09/2017
*/
/*#include <stdio.h>

int main(void) {

   int i, x, sum=0;

   printf("Input integer ");
   scanf("%d", &x);

   for (i=1; i<=x; i++){
       *******************
   }
   printf("Sum of 1 to %d = %d\n", x, sum);

   return (0);
}*/
/*
loop2.c: In function 'main':
	loop2.c:12:4: error: expected expression before '}' token
*/
/**
Explanation:
 At line number 12 given expression is invalid so compiler give error
*/


