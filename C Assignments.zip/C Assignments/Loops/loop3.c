/**
Title :Loop : 3.
Date : 19/09/2017
*/
/*#include <stdio.h>

int main(void) {

   int i, j;

   for (i=0; i<10; i++){
       for (j=0; j<10-i; j++){
           printf("*");
       }
       printf("\n");
   }

   return (0);
}*/
/*
Output:
**********
*********
********
*******
******
*****
****
***
**
*
*/
/**
Explanation :
1.start
2. start first loop used for it print number of rows we want
3. Second loop is used for in each row how we print * pattern
4. Stop
*/
