/**
Title :Que 17.Program to Count Number of Words and Number of
Characters in a String
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    char contents[100];
    int i,countchar=0,countword=0;
    printf("Enter String\n");
    gets(contents);
    for(i=0;contents[i]!=NULL;i++)
    {
        countchar++;
        if(contents[i]==' ')
        {
            countword++;
        }
    }
    printf("Number of characters : %d\n",countchar);
    printf("Number of word : %d\n",countword);
    return 0;
}
