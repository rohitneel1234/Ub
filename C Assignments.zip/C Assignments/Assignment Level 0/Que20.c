/**
Title :Que 20.write a program that define how structure and union is
differ?
Date : 19/09/2017
*/
#include <stdio.h>
#include <string.h>

// declaring structure
struct struct_example
{
    int integer;
    float dec;
    char name[30];
};

// declaraing union

union union_example
{
    int integer;
    float dec;
    char name[30];
};

void main()
{
    // creating variable for structure
    struct struct_example seg={17,52,"C programming"};

    // creating variable for union
    union union_example ueg={17,52,"C programming"};


    printf("structure data:\n integer: %d\n"
                "dec: %.2f\n name: %s\n",
                seg.integer, seg.dec, seg.name);
    printf("\nunion data:\n integeer: %d\n"
                 "dec: %.2f\n name: %s\n",
                ueg.integer, ueg.dec, ueg.name);


    // Size of struct and union
    printf("\nsize of structure : %d\n", sizeof(seg));
    printf("size of union : %d\n", sizeof(ueg));

    // Accessing all elements
    printf("\n Accessing all members at a time:");
    seg.integer = 200;
    seg.dec = 50;
    strcpy(seg.name, "C programming");

    printf("structure data:\n integer: %d\n "
                "dec: %.2f\n name: %s\n",
            seg.integer, seg.dec, seg.name);

    ueg.integer = 200;
    ueg.dec = 50;
    strcpy(ueg.name, "C Programming");

    printf("\nunion data:\n integeer: %d\n "
                "dec: %.2f\n name: %s\n",
            ueg.integer, ueg.dec, ueg.name);

    printf("\n Accessing one member at time:");

    printf("\nstructure data:");
    seg.integer = 169;
    printf("\ninteger: %d", seg.integer);

    seg.dec = 196;
    printf("\ndec: %f", seg.dec);

    strcpy(seg.name, "C programming");
    printf("\nname: %s\n", seg.name);

    printf("\n union data:");
    ueg.integer = 169;
    printf("\ninteger: %d", ueg.integer);

    ueg.dec = 196;
    printf("\ndec: %f", ueg.dec);

    strcpy(ueg.name, "C programming");
    printf("\nname: %s\n", ueg.name);

    //When altering members affect on union
    printf("\nAltering a member value:\n");
    seg.integer = 11294;
    printf("structure data:\n integer: %d\n "
                " dec: %.2f\n name: %s\n",
                seg.integer, seg.dec, seg.name);

    ueg.integer = 11294;
    printf("union data:\n integer: %d\n"
           " dec: %.2f\n name: %s\n",
            ueg.integer, ueg.dec, ueg.name);
}
