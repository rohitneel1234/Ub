/**
Title :Que 19.Program to Show Call by Value & Call by Reference
concept
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number,number1,number2;
    printf("Enter a number\n");
    scanf("%d",&number);
    printf("Before Call by value number is %d\n",number);
    // Call by value
    number1=call_by_value(number); // calling function with parameter
    printf("After Call by value number is %d\n",number1);
    //call by Reference
    printf("Before Call by reference number is %d\n",number);
    number2=call_by_reference(&number);
    printf("After call by reference number is %d\n",number2);
    return 0;
}
//Called method
int call_by_value(int no)
{
    no*=10;
    return no;
}
int call_by_reference(int *num)
{
    *num+=10;
    return *num;
}
