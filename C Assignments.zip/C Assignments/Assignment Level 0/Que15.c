/**
Title :(15) Enter total seconds from user and print in format of �hh :
mm : ss�.
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int second,hr,min;
    printf("Enter seconds\n");
    scanf("%d",&second);
    hr=second/3600;
    second=second%3600;
    min=second/60;
    second=second%60;
    printf("hh:mm:ss : %d:%d:%d\n",hr,min,second);
    return 0;
}
