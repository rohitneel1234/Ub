/**
Title :Que16.Program to Find addition of a given array element using
Recursion.
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int size,i;
    printf("Enter how many elements you want\n");
    scanf("%d",&size);
    int number[size];
    printf("Enter number\n");
    for(i=0;i<size;i++)
    {
        scanf("%d",&number[i]);
    }
    int sum=add(number,size-1);
    printf("Addition of array elements: %d\n",sum);
    return 0;
}
int add(int *elearray,int index)
{
    if(NULL==elearray || index<0)
    {
        return 0;
    }
    return elearray[index]+add(elearray,index-1);
}
