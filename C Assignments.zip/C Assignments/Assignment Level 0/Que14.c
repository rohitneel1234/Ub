/**
Title :(14) Implement program which gives output as below:
Input Output
75.403 403.75
Date : 19/09/2017
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    float number=75.403;
    int n1=75.403*1000;
    int n2=n1/1000;
    int n3=n1%1000;
    float output=n3+(float)n2/100;
    printf("Input : %.3f\n",number);
    printf("Output: %.2f",output);
    return 0;
}

